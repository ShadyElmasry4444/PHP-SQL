<?php
require 'connection.php';
$query_string = $_SERVER['QUERY_STRING'];
$data = explode('=',$query_string);
$query = "SELECT * FROM teachers where id = $data[1]";
$sql = $con->prepare($query);
$sql->execute();
$teacher = $sql->fetch(PDO::FETCH_ASSOC);
$query = "SELECT * FROM `subjects`;";
$sql = $con->prepare($query);
$sql->execute();
$subjects = $sql->fetchAll(PDO::FETCH_ASSOC);



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="assign.css">

</head>
<body>
<form action="./assign_subject.php" method="post">
    <input type="hidden" name="id" value="<?php echo $teacher['id']?>">
    <label for="name">name</label>
    <?php echo $teacher['name']?>
    <label for="subject_id">subject</label>
    <select name="subject_id" value="<?php echo $teacher['subject_id']?>">
        <?php foreach($subjects as $subject): ?>
            <option value="<?php echo $subject['id']?>"><?php echo $subject['name'];?></option>
        <?php endforeach; ?>
    </select>
    <input type="submit">
</form>

    
</body>
</html>