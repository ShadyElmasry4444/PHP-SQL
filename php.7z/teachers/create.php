<?php
require_once 'connection.php';
$query = "SELECT DISTINCT t2.id as id , t2.name as supervisor_name FROM `teachers` t1 join teachers t2 ON t2.id = t1.supervisor_id";
$sql = $con->prepare($query);
$sql->execute();
$supervisors = $sql->fetchAll(PDO::FETCH_ASSOC);
$subjectQuery = "SELECT DISTINCT * FROM `subjects`";
$sqlSubject = $con->prepare($subjectQuery);
$sqlSubject->execute();
$subjects = $sqlSubject->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="create.css">
</head>
<body>
<form action="./teachers.php" method="post">
    <label for="name">name</label>
    <input type="text" name="name">
    <label for="email">email</label>
    <input type="email" name="email">
    <label for="password">password</label>
    <input type="password" name="password">
    <label for="age">age</label>
    <input type="number" name="age">
    <label for="gender">gender</label>
    <input type="radio" name="gender" value="male" id="">male
    <input type="radio" name="gender" value="female" id="">female
    <label for="salary">salary</label>
    <input type="number" name="salary">
    <label for="supervisor_id">supervisor name</label>
    <select name="supervisor_id" id="">
        <?php foreach($supervisors as $supervisor): ?>
            <option value="<?php echo $supervisor['id']?>"><?php echo $supervisor['supervisor_name'];?></option>
        <?php endforeach; ?>
    </select>
    <input type="submit">
</form>
    
</body>
</html>
