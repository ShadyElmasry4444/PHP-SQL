<?php 
// assign subject
require('connection.php');
['id' => $id, 'subject_id' => $subject_id] = $_REQUEST;
// foreach ($subject_id as $subject_id_)
// { 

// }
$query_5 = "INSERT INTO `teachers_subjects` (`teacher_id`, `subject_id`) VALUES (
    '$id',
    '$subject_id'
 )";


$sql = $con->prepare($query_5);
$result = $sql->execute();
var_dump($_REQUEST);

if($result == 0){
    echo file_get_contents('errors.html');
}else{
    header('Location:http://localhost/teachers_subjects/index.php'); 
}
?>