document.querySelector('.create-teacher2').addEventListener('click', () => {
    window.location.href = window.location.origin + '/teachers/create.php';
})