<?php
$db = 'mysql:host=localhost;dbname=php_72';
$con = new PDO($db ,'root','');