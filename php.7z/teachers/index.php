<!--  get teachers from database  -->
<?php
require('connection.php');
$query_string = $_SERVER['QUERY_STRING'];
$data = explode('=',$query_string);
if($data[0] == 'delete'){
    $query = "DELETE FROM teachers WHERE id = $data[1]";
    $sql = $con->prepare($query);    
    $sql->execute();
}
?>

<?php
// start connection between server and database
// database type , host , database name
// mysql , http://mydatabase.com , mydatabase 
$query = "SELECT t1.*, t2.name as supervisor_name FROM `teachers` t1 join teachers t2 ON t2.id = t1.supervisor_id";
$sql =  $con->prepare($query);
$result = $sql->execute();
$teachers = $sql->fetchAll(PDO::FETCH_ASSOC);
?>

<!-- display teachers inside tables -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="index.css">
</head>
<body>
    <table>
        <thead>
            <tr>
                <th>id</th>
                <th>name</th>
                <th>email</th>
                <th>age</th>
                <th>gender</th>
                <th>salary</th>
                <th>supervisor name</th>
                <th>actions</th>
            </tr>
        </thead>
        <tbody>
            <!-- crud  create read update delete-->
            <?php foreach($teachers as $teacher): ?>
                <tr>
                    <td><?php echo $teacher['id'];?></td>
                    <td><?php echo $teacher['name'];?></td>
                    <td><?php echo $teacher['email'];?></td>
                    <td><?php echo $teacher['age'];?></td>
                    <td><?php echo $teacher['gender'];?></td>
                    <td><?php echo $teacher['salary'];?></td>
                    <td><?php echo $teacher['supervisor_name'];?></td>
                    <td>
                       <a href="./update.php?teacher_id=<?php echo $teacher['id']?>"><i class="fa-solid fa-pen-to-square"></i></a>
                       <a href="./assign.php?teacher_id=<?php echo $teacher['id']?>"><i class="fa-solid fa-s"></i></a>
                       <a href="<?php echo $_SERVER['PHP_SELF'].'?delete='.$teacher['id']?>"><i class="fa-solid fa-trash-can"></i></a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <button class="create-teacher2">create teacher</button>
    <!-- delete icon row -->
    
<script src="app2.js"></script>
</body>
</html>