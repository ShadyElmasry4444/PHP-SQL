<?php 
// update teacher 
require('connection.php');
['id' => $id ,'name' => $name ,'email' => $email  ,'age' => $age, 'gender' => $gender, 'salary' => $salary,'supervisor_id' => $supervisor_id ] = $_REQUEST;
$query = "UPDATE teachers SET name = '$name' , email = '$email' , age = '$age', gender = '$gender', salary = '$salary', supervisor_id = '$supervisor_id' WHERE id = '$id'";
$sql = $con->prepare($query);
$result = $sql->execute();
if($result == 0){
    echo file_get_contents('errors.html');
}else{
    header('Location:http://localhost/teachers/index.php'); 
}
?>