<?php
require 'connection.php';
['name' => $name ,'email' => $email ,'password' => $password ,'age' => $age ,'gender' => $gender ,'salary' => $salary ,'supervisor_id' => $supervisor_id] = $_REQUEST;
$password = sha1($password);

$query = "INSERT INTO teachers (name,email,password,age,gender,salary,supervisor_id) VALUES ('$name','$email','$password','$age','$gender','$salary','$supervisor_id')";
$sql = $con->prepare($query);
$result = $sql->execute();



// $query_2 = "SELECT id FROM teachers WHERE name = $name";
// $sql = $con->prepare($query_2);
// $teacher_id = $sql->execute();
// $subject_ids = array();


// foreach ($subject as $subject_) {
//     $query_3 = "SELECT id FROM subjects WHERE name = $subject_";
//     $sql = $con->prepare($query_3);
//     $result_3 = $sql->execute();

//     array_push($subject_ids,$result_3);
// } 

// foreach ($subject_ids as $subject_id)
// {
//     $query_5 = "INSERT INTO teachers_subjects VALUES (
//         '$subject_id',
//         '$teacher_id'
//     )";
// }

if($result == 0){
    echo file_get_contents('errors.html');
}else{

    header('Location:http://localhost/teachers/index.php'); 

}


?>