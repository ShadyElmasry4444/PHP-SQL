<?php
require('connection.php');
$query_string = $_SERVER['QUERY_STRING'];
$data = explode('=',$query_string);

?>

<?php
// start connection between server and database
// database type , host , database name
// mysql , http://mydatabase.com , mydatabase 
$query = "SELECT * FROM `teachers_subjects`";
$sql =  $con->prepare($query);
$result = $sql->execute();
$teachers_subjects = $sql->fetchAll(PDO::FETCH_ASSOC);

?>

<!-- display teachers inside tables -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
    <table>
        <thead>
            <tr>
                <th>id</th>
                <th>teacher_id</th>
                <th>subject_id</th>
            </tr>
        </thead>
        <tbody>
            <!-- read-->
            <?php foreach($teachers_subjects as $teachers_subject): ?>
                <tr>          
                    <td><?php echo $teachers_subject['id'];?></td>
                    <td><?php echo $teachers_subject['teacher_id'];?></td>
                    <td><?php echo $teachers_subject['subject_id'];?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

</body>
</html>
