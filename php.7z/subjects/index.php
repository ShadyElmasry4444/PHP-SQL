<!--  get subjects from database  -->
<?php
require('connection.php');
$query_string = $_SERVER['QUERY_STRING'];
$data = explode('=',$query_string);
if($data[0] == 'delete'){
    $query = "DELETE FROM subjects WHERE id = $data[1]";
    $sql = $con->prepare($query);    
    $sql->execute();
}
?>

<?php
// start connection between server and database
// database type , host , database name
// mysql , http://mydatabase.com , mydatabase 
$query = "SELECT * FROM subjects";
$sql =  $con->prepare($query);
$result = $sql->execute();
$subjects = $sql->fetchAll(PDO::FETCH_ASSOC);
?>

<!-- display subjects inside tables -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="index.css">
</head>
<body>
    <table>
        <thead>
            <tr>
                <th>id</th>
                <th>name</th>
                <th>credit_hours</th>
                <th>grade</th>
                <th>actions</th>
            </tr>
        </thead>
        <tbody>
            <!-- crud  create read update delete-->
            <?php foreach($subjects as $subject): ?>
                <tr>
                    <td><?php echo $subject['id'];?></td>
                    <td><?php echo $subject['name'];?></td>
                    <td><?php echo $subject['credit_hours'];?></td>
                    <td><?php echo $subject['grade'];?></td>
                    <td>
                       <a href="./update.php?subject_id=<?php echo $subject['id']?>"><i class="fa-solid fa-pen-to-square"></i></a>
                       <a href="<?php echo $_SERVER['PHP_SELF'].'?delete='.$subject['id']?>"><i class="fa-solid fa-trash-can"></i></a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <button class="create-subject3">create subject</button>
    <!-- delete icon row -->
    
<script src="app3.js"></script>
</body>
</html>