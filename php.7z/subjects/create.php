<?php
require 'connection.php';
$query = "SELECT DISTINCT t2.id as id , t2.name as subject_name FROM `subjects` t1 join subjects t2 ON t2.id = t1.subject_id";
$sql = $con->prepare($query);
$sql->execute();
$subjects = $sql->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="create.css">
</head>
<body>
<form action="./subjects.php" method="post">
    <label for="name">name</label>
    <input type="text" name="name">
    <label for="credit_hours">credit_hours</label>
    <input type="credit_hours" name="credit_hours">
    <label for="grade">grade</label>
    <input type="grade" name="grade">
    <input type="submit">
</form>
    
</body>
</html>