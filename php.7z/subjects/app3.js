document.querySelector('.create-subject3').addEventListener('click', () => {
    window.location.href = window.location.origin + '/subjects/create.php';
})