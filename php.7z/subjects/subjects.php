<?php
require 'connection.php';
['name' => $name ,'credit_hours' => $credit_hours ,'grade' => $grade] = $_REQUEST;
$query = "INSERT INTO subjects (name,credit_hours,grade) VALUES ('$name','$credit_hours','$grade')";
$sql = $con->prepare($query);
$result = $sql->execute();
if($result == 0){
    echo file_get_contents('errors.html');
}else{
    header('Location:http://localhost/subjects/index.php'); 
}
?>  